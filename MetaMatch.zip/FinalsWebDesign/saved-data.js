 // JavaScript functionality to go back to the homepage
 function backToHome() {
    window.location.href = "homepage2.html#main-content"; // Change the URL to the homepage
}

// Simulate loading delay (You can adjust the delay time as needed)
setTimeout(function() {
    // Hide loader and show container
    document.querySelector(".loader-container").style.display = "none";
    document.querySelector(".container").style.display = "block";
}, 2000); // Adjust the delay time (in milliseconds) as needed

